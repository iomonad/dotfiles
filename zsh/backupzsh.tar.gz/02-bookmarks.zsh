#!/usr/bin/zsh

hash -d b=~/bin
hash -d rc=~/etc/rc.d/
hash -d v=~/.vim
hash -d x=~/.config

# vim: set ts=2 expandtab sw=2:
